from myPackage import myModule
